 //  navbar start
document.addEventListener('DOMContentLoaded', function () {
    var mobileMenu = document.getElementById('mobile-menu');
    var navList = document.getElementById('nav-list');

    mobileMenu.addEventListener('click', function () {
        navList.classList.toggle('show');
        mobileMenu.classList.toggle('acive');
    });
});

 
const timeline = gsap.timeline();
timeline.from("#page1heading1",{
    x:-1000,
    duration:1, 
    stagger: 0.2, 
})
timeline.from("#colorchange", {
    duration: 2,
    colorProps: { value: "green" },
    y: -2000,
    rotate: 360,
    ease: "back.out(1.7)"
});
timeline.from("bottom1", {
    x:-400, 
    duration:2
  });
timeline.from("#page3-headings-h2",{
    opacity:-1,

      x: -1000, 
    duration:1, 
    scrollTrigger: {
        trigger: "#page3-headings-h2", 
        start: "top center",
        end: "bottom center",
        scrub: 1, 
    },
  })
  gsap.from("#page4index",{
    y:150,
    duration:3,
    opacity:0,
    scrollTrigger:"#page4index",
    ease:"bounce.out",
    
})
gsap.from("#leftbox4,#rightbox",{
    y:150,
    duration:3,
    opacity:0,
    scrollTrigger:"#leftbox4,#rightbox",
    ease:"bounce.out",
    
})
// #page2button
  gsap.from("#page2button", {
    opacity: 0,
    duration: 1.5,
    textShadow: "0 0 0 rgba(255, 0, 0, 0.5)", // Initial text-shadow style
    ease: "power4.out",
    onComplete: addTextShadowAnimation,
});

function addTextShadowAnimation() {
    gsap.to("#page2button", {
        textShadow: "10px 10px 10px rgba(0, 0, 255, 0.7)", // Final text-shadow style
        duration: 1.5,
        repeat: -1, // Repeat the animation indefinitely
        yoyo: true, // Reverse the animation on each repeat
        ease: "power4.inOut",
    });
}
// page3headingsp
const text = document.getElementById("page3headingsp");

        document.addEventListener("mousemove", (e) => {
            const { clientX, clientY } = e;

            gsap.to(text, {
                textShadow: `${clientX / 30}px ${clientY / 30}px 10px rgba(0, 0, 0, 0.5)`,
                duration: 0.5,
                ease: "power2.out",
            });
        });

// this is the starting of Explore.html  
const main = document.querySelector("#main");
const heading = document.getElementById("headingcorces");
const name = document.getElementById("Courses-name");
function updateCourses(courseName) {
    // Update Courses-name text
    var coursesNameElement = document.getElementById('Courses-name');
    coursesNameElement.innerText = courseName;

    // Show headingcorces
    var headingCourses = document.getElementById('headingcorces');
    headingCourses.style.display = 'block';
  }
// this is the starting of not Explore.html 
// scroll start
const locoScroll = new LocomotiveScroll({
    el: document.querySelector("#main"),  
    smooth: true, // Enable smooth scrolling
    // Add other options as needed
});

// scroll end
